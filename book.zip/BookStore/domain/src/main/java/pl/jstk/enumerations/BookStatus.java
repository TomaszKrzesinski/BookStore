package pl.jstk.enumerations;

public enum BookStatus {

	FREE, LOAN, MISSING
}
